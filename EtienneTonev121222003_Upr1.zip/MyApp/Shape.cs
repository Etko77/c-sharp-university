using System;

interface IElliptical
{
    bool isElliptical();
}

abstract class Shape
{
    private int color; 

    public class BasicColors
    {
        public static int Blue = 1;
        public static int Red = 2;
        public static int Green = 3;
    }

    public int Color
    {
        get
        {
            int r = (color >> 16) & 0xFF;
            int g = (color >> 8) & 0xFF;
            int b = color & 0xFF;

            if (r == 0 && g == 0 && b == 255)
                return BasicColors.Blue;
            else if (r == 255 && g == 0 && b == 0)
                return BasicColors.Red;
            else if (r == 0 && g == 255 && b == 0)
                return BasicColors.Green;

            return 0; 
        }
        set
        {
            int alpha = 255; 

            switch (value)
            {
                case 1: 
                    color = (alpha << 24) | (0 << 16) | (0 << 8) | 255;
                    break;

                case 2: 
                    color = (alpha << 24) | (255 << 16) | (0 << 8) | 0;
                    break;

                case 3: 
                    color = (alpha << 24) | (0 << 16) | (255 << 8) | 0;
                    break;

                default:
                    throw new ArgumentException("Невалиден цвят!");
            }
        }
    }

    public abstract double Perimeter();
    public abstract double Area();
}

class Rectangle: Shape, IElliptical
{
        protected double width;
        protected double height;
    public Rectangle(double width, double height)
    {
        this.width = width;
        this.height = height;
    }
    public override double Area()
    {
        return width * height;
    }
    public override double Perimeter()
    {
        return 2 * ( width + height);
    }
    public bool isElliptical()
    {
        return false;
    }
}
class Circle : Shape, IElliptical
{
    private double radius;

    public Circle(double radius)
    {
        this.radius = radius;
    }

    public override double Perimeter()
    {
        return 2 * Math.PI * radius;
    }

    public override double Area()
    {
        return Math.PI * radius * radius;
    }

    public bool isElliptical()
    {
        return true;
    }
}

class Square : Rectangle
{
    public Square(double side) : base(side, side)
    {
    }

    public static double CalculateArea(double side)
    {
        return side * side;
    }
}

class Triangle<T> where T : struct
{
    public T A { get; private set; }
    public T B { get; private set; }
    public T C { get; private set; }

    private Triangle(T a, T b, T c)
    {
        A = a;
        B = b;
        C = c;
    }

    public static bool GetInstance(T a, T b, T c, out Triangle<T>? triangle)
    {
        triangle = null;

        if (typeof(T) != typeof(int) && typeof(T) != typeof(float))
            return false;

        double da = Convert.ToDouble(a);
        double db = Convert.ToDouble(b);
        double dc = Convert.ToDouble(c);

        if (da + db > dc && da + dc > db && db + dc > da)
        {
            triangle = new Triangle<T>(a, b, c);
            return true;
        }

        return false;
    }
}

class Program
{
    static void Main()
    {
        if (Triangle<int>.GetInstance(3, 4, 5, out var t1))
            Console.WriteLine("Създаден int триъгълник");

        if (Triangle<float>.GetInstance(2.5f, 3.5f, 4f, out var t2))
            Console.WriteLine("Създаден float триъгълник");

        if (!Triangle<double>.GetInstance(3, 4, 5, out var t3))
            Console.WriteLine("Типът не е позволен");
    }
}